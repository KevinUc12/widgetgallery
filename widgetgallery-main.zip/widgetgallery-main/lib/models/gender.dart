enum Gender {
  female,
  male,
  notSpecify,
}
